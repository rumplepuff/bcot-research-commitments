# EXPLORATORY E3 (2026-11-06). Run from the PNP_RW1 root. Plain bootstrap, NOT the frozen keyed stream.
import json,math,random
a=json.load(open('confirmatory/results/PNPRW1_IT1_CONF_analysis.json'))
print("EXPLORATORY E3: pooled GM with one family left out; plain bootstrap (10,000, random.Random(20261106)), NOT the frozen keyed stream. input analysis 1bfb7b0a...0407")
fams=['funnel','bypass','mesh','trap','trap_hostile']
for drop in [None]+fams:
    l=[p['l'] for p in a['per_instance'] if p['family']!=drop]
    gm=math.exp(sum(l)/len(l)); rng=random.Random(20261106); bs=[]
    for _ in range(10000):
        s=[l[rng.randrange(len(l))] for _ in l]; bs.append(math.exp(sum(s)/len(s)))
    bs.sort(); print(f"without {drop}: n={len(l)} GM={gm:.4f} CI~[{bs[249]:.4f}, {bs[9749]:.4f}]")
