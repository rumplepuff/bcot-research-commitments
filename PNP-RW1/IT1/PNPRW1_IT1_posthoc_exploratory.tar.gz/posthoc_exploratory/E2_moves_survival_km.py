# EXPLORATORY E2 (2026-11-06). Run from the PNP_RW1 root. Kaplan-Meier on moves; budget stops treated as censoring (a strong assumption, see report).
import json
r=json.load(open('confirmatory/results/PNPRW1_IT1_CONF.json'))
print("EXPLORATORY E2: Kaplan-Meier on MOVES (all runs; success = event, budget stop = censored at moves made). input 6dea1a3f...2e25")
print("P(goal reached within m moves); avoids conditioning on success; assumes budget censoring is non-informative")
def km(pts, ms):
    pts=sorted(pts); out={}
    times=sorted(set(t for t,e in pts if e)); res=[]; S=1.0
    for t in times:
        at=sum(1 for x,_ in pts if x>=t); d=sum(1 for x,e in pts if x==t and e)
        S*=1-d/at; res.append((t,S))
    for m in ms:
        s=1.0
        for t,v in res:
            if t<=m: s=v
        maxobs=max(x for x,_ in pts)
        out[m]=None if m>maxobs else round(1-s,3)
    return out
fams={}
for row in r['rows']:
    for a in ('W0','W1'):
        for x in row[a]: fams.setdefault(row['family'],{}).setdefault(a,[]).append((x['ops']['move'], x['success']))
ms=[5,10,25,50,100,150,200]
for f,d in fams.items():
    for a in ('W0','W1'):
        mx=max(t for t,_ in d[a])
        print(f"{f:13s} {a} max_moves_observed={mx:4d}", km(d[a],ms))
