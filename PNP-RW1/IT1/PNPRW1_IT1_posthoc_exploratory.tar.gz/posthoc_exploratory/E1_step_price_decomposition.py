# EXPLORATORY E1 (2026-11-06). Run from the PNP_RW1 root: python3 -I -B posthoc_exploratory/E1_step_price_decomposition.py
# NOTE (review 2026-11-06): "units per step" here is total work / GOAL TESTS, not per graph move; see E1r.
import json, math, statistics as st
r=json.load(open('confirmatory/results/PNPRW1_IT1_CONF.json'))
fams={}
for row in r['rows']:
    f=fams.setdefault(row['family'],{'W0':[], 'W1':[], 'lr':[], 'lr4':[]}); B=row['B_w']
    for a in ('W0','W1'): f[a]+=row[a]
    def rmst(runs, price=None):
        return sum((x['capped_cost'] if price is None else (min(price*x['ops']['goal']+x['ops']['restart'],B) if x['success'] else B)) for x in runs)/len(runs)
    f['lr'].append(math.log(rmst(row['W1'])/rmst(row['W0']))); f['lr4'].append(math.log(rmst(row['W1'],4)/rmst(row['W0'],4)))
A=[];A4=[]
print("EXPLORATORY. input sha256 6dea1a3f...2e25")
print("family | median moves on successes W0/W1 | units per step W0/W1 | GM actual | GM W1 re-priced at 4/step")
for n,f in fams.items():
    o=[(st.median([x['ops']['move'] for x in f[a] if x['success']]), round(sum(x['ops']['total'] for x in f[a])/sum(x['ops']['goal'] for x in f[a]),2)) for a in ('W0','W1')]
    A+=f['lr'];A4+=f['lr4']
    print(n,"|",o[0][0],"/",o[1][0],"|",o[0][1],"/",o[1][1],"|",round(math.exp(st.mean(f['lr'])),3),"|",round(math.exp(st.mean(f['lr4'])),3))
print("pooled GM actual",round(math.exp(st.mean(A)),4),"re-priced",round(math.exp(st.mean(A4)),4))
