# PNP-RW1 IT1 post-hoc EXPLORATORY analyses (NOT confirmatory, NOT part of the IT1 verdict)

> **CORRECTION NOTICE (2026-11-06).** The original E1 output (`E1_step_price_decomposition.txt`) divides total work by
> GOAL TESTS and mislabels the result "units per step"; its re-priced column rests on that denominator. Both are
> SUPERSEDED by `E1r_E2r_review_corrections.txt` (work per graph move, break-even, end states). The original E1 files
> are kept unchanged for historical traceability only, not as current scientific interpretation.
> E2's move-based estimates treat budget stops as censoring; censoring here depends on the policy, so E2 cannot
> establish an intrinsic navigation advantage. Inputs needed: confirmatory/results/PNPRW1_IT1_CONF.json (sha256
> 6dea1a3f...2e25) and PNPRW1_IT1_CONF_analysis.json (sha256 1bfb7b0a...0407), published alongside this archive.
Written after the confirmatory result was known (2026-11-06). Reads the frozen run record read-only; reruns nothing.
E1 step_price_decomposition: per family, median moves on successful runs, accounted units per goal check (≈ per step),
GM actual, and GM with W1's steps re-priced at W0's ~4 units (successes only; W1 failures kept at B_w, which
FAVOURS W0 because cheaper W1 steps would also have converted some budget failures into successes).
E2 moves_survival_km: Kaplan-Meier on moves over all runs; budget stops treated as censoring (policy-dependent; see report).
E3 population_sensitivity: pooled GM with each family left out; plain bootstrap, not the frozen keyed stream.
E1r_E2r_review_corrections (after team review 6 Nov 2026): work per GRAPH MOVE (E1 divided by goal tests and mislabelled it
"per step"), break-even move reduction, end states, observed success within 200 moves, mesh move variation.
Each .py reruns from the PNP_RW1 root (python3 -I -B posthoc_exploratory/<name>.py) and reproduces its .txt byte for byte.
