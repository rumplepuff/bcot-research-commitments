# EXPLORATORY E1r/E2r (2026-11-06, after team review). Run from the PNP_RW1 root.
import json, statistics as st
r=json.load(open('confirmatory/results/PNPRW1_IT1_CONF.json'))
print("EXPLORATORY E1r/E2r (corrections after team review, 2026-11-06). input 6dea1a3f...2e25. E1 and E2 files are kept unchanged.")
F={}
for row in r['rows']:
    for a in ('W0','W1'):
        d=F.setdefault(row['family'],{}).setdefault(a,{'tot':0,'goal':0,'move':0,'end':{},'w200':0,'n':0,'mv':[]})
        for x in row[a]:
            d['tot']+=x['ops']['total']; d['goal']+=x['ops']['goal']; d['move']+=x['ops']['move']; d['n']+=1
            d['end'][x['end']]=d['end'].get(x['end'],0)+1
            if x['success'] and x['ops']['move']<=200: d['w200']+=1
        if row['family']=='mesh' and a=='W0': d['mv'].append(len({x['ops']['move'] for x in row[a]}))
print("family | units/goal test W0 W1 | units/move W0 W1 | break-even move reduction (1 - u0/u1) | end states W0 | end states W1 | observed success within 200 moves W0 W1")
for f,d in F.items():
    a,b=d['W0'],d['W1']
    u0g,u1g=a['tot']/a['goal'],b['tot']/b['goal']; u0m,u1m=a['tot']/a['move'],b['tot']/b['move']
    print(f, "|", round(u0g,2), round(u1g,2), "|", round(u0m,2), round(u1m,2), "|", f"{1-u0m/u1m:.1%}", "|", a['end'], "|", b['end'], "|", f"{a['w200']/a['n']:.2%}", f"{b['w200']/b['n']:.2%}")
m=F['mesh']['W0']['mv']; print("mesh W0: instances with varying move counts across runs:", sum(1 for v in m if v>1), "of", len(m))
mv=[x['ops']['move'] for row in r['rows'] if row['family']=='mesh' for x in row['W0']+row['W1']]; print("mesh move range", min(mv), max(mv))
